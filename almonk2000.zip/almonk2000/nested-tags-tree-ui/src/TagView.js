/* eslint-disable no-unused-vars */

import './TagView.css';
import React, { useState } from 'react';

const TagView = ({ tag, onUpdate, onAddChild }) => {
  const [collapsed, setCollapsed] = useState(false);
  const [name, setName] = useState(tag.name);
  const [data, setData] = useState(tag.data || '');

  const toggleCollapse = () => {
    setCollapsed(!collapsed);
  };

  // eslint-disable-next-line no-unused-vars
  const handleNameChange = (event) => {
    setName(event.target.value);
  };

  const handleDataChange = (event) => {
    const newData = event.target.value;
    setData(newData);
  
    const updatedTag = { ...tag, data: newData };
    onUpdate(tag, updatedTag);
  };

  const handleAddChild = () => {
    onAddChild(tag);
  };

  return (
    <div className="tag">
      <div className="tag-header">
        <div className="tag-header-row">
          <button className="collapse-button" onClick={toggleCollapse}>
            {collapsed ? '>' : 'v'}
          </button>
          {!collapsed && (
            <>
              <span className="tag-name">{tag.name}</span>
              {tag.data !== undefined && tag.data !== null ? (
                <input
                  type="text"
                  className="tag-data"
                  value={data}
                  onChange={handleDataChange}
                />
              ) : (
                <span className="tag-data. has-data"></span>
              )}
            </>
          )}
          {!collapsed && (
            <button className="add-child-button" onClick={handleAddChild}>
              Add Child
            </button>
          )}
        </div>
      </div>
      {!collapsed && (
        <div className="tag-children">
          {tag.children &&
            tag.children.map((child, index) => (
              <TagView
                key={index}
                tag={child}
                onUpdate={onUpdate}
                onAddChild={onAddChild}
              />
            ))}
        </div>
      )}
    </div>
  );
};

export default TagView;
