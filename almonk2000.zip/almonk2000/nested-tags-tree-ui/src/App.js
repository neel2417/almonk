// src/App.js
import React, { useState } from 'react';
import './App.css';

import TagView from './TagView';
import treeData from './treeData';

function App() {
  const [tree, setTree] = useState(treeData);
  const [exportedData, setExportedData] = useState('');

  const handleUpdate = (updatedTree) => {
    setTree(updatedTree);
  };

  const handleAddChild = (parentTag) => {
    const newChild = { name: 'New Child', data: 'Data', children: [] };
    const updatedTree = addChildToTree(tree, parentTag, newChild);
    handleUpdate(updatedTree);
  };

  const addChildToTree = (currentTag, parentTag, newChild) => {
    if (currentTag === parentTag) {
      return { ...currentTag, children: [...(currentTag.children || []), newChild] };
    }

    if (currentTag.children) {
      const updatedChildren = currentTag.children.map((child) =>
        addChildToTree(child, parentTag, newChild)
      );
      return { ...currentTag, children: updatedChildren };
    }

    return currentTag;
  };

  const handleExport = () => {
    const jsonString = JSON.stringify(tree, null, 2);
    setExportedData(jsonString);
  };

  return (
    <div className="App">
      <h1>Nested Tags Tree</h1>
      <TagView
        tag={tree}
        onAddChild={handleAddChild}
        // Pass other necessary props to TagView
      />
      <div style={{ margin: '20px 0' }}>
        <button className="export-button" onClick={handleExport}>
          Export
        </button>
      </div>
      <textarea
        value={exportedData}
        readOnly
        style={{ width: '100%', height: '200px' }}
      />
    </div>
  );
}

export default App;
